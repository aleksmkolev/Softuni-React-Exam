import { createContext } from "react"; 

export const UserContext = createContext({
    _id: '',
    email: '', 
    username: '',
    accessToken: '', 
    userLoginHandler: () => null,
    userRegisterHandler: () => null,
    useLogoutHandler: () => null,
});